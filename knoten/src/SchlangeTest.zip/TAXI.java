public class TAXI 
extends BILD
implements AUFLISTBAR
{
    private String kfz;
    
    public TAXI(String kfz)
    {
        super(900, 350, "taxi.png");
        this.kfz = kfz;
    }
    
    public String nenneInfo() {
        return this.kfz;
    }
}
