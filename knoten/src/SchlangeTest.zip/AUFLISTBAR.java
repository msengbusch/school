public interface AUFLISTBAR
{
    public String nenneInfo();
}
